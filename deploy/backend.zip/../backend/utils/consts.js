const MONGO_URI = process.env.MONGODB_URI || "mongodb://localhost/server";

module.exports = MONGO_URI;
