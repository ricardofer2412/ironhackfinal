require("dotenv").config();

module.exports = {
  USER: "kingtraderdonotreply@gmail.com",
  PASS: "5618096706",

  //   USER: process.env.USER,
  //   PASS: process.env.PASS,
};
